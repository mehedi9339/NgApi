import { Category } from './category.model';
import { OrderDetails } from './order-details.model';

export class Product {
    Id: number;
    Name: string
    Description: string
    CatID: number
    ImagePath: string
    Price: number
    Category: Category
    OrderDetails: OrderDetails[]
}
