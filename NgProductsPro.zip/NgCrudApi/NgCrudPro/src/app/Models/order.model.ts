import { Customer } from './customer.model';
import { OrderDetails } from './order-details.model';

export class Order {
    Id: number;
    Orderdate: string;
    CustId: number;
    TotalQty: number;
    TotalPrice: number;
    Customer: Customer;
    OrderDetails: OrderDetails[];
}
