import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddOrEditCustomerComponent } from './Components/Customer/add-or-edit-customer/add-or-edit-customer.component';
import { ViewCustomersComponent } from './Components/Customer/view-customers/view-customers.component';
import { HomeComponent } from './Components/home/home.component';
import { NotFoundComponent } from './Components/not-found/not-found.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ViewCategoryComponent } from './Components/Category/view-category/view-category.component';
import { AddOrEditCategoryComponent } from './Components/Category/add-or-edit-category/add-or-edit-category.component';

@NgModule({
  declarations: [
    AppComponent,
    AddOrEditCustomerComponent,
    ViewCustomersComponent,
    HomeComponent,
    NotFoundComponent,
    ViewCategoryComponent,
    AddOrEditCategoryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
