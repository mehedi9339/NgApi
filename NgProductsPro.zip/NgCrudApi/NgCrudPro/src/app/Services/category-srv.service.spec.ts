import { TestBed } from '@angular/core/testing';

import { CategorySrvService } from './category-srv.service';

describe('CategorySrvService', () => {
  let service: CategorySrvService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CategorySrvService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
