import { TestBed } from '@angular/core/testing';

import { CustomerSrvService } from './customer-srv.service';

describe('CustomerSrvService', () => {
  let service: CustomerSrvService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustomerSrvService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
