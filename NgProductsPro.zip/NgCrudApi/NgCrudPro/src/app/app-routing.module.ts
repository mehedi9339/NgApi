import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './Components/home/home.component';
import { ViewCustomersComponent } from './Components/Customer/view-customers/view-customers.component';
import { AddOrEditCustomerComponent } from './Components/Customer/add-or-edit-customer/add-or-edit-customer.component';
import { NotFoundComponent } from './Components/not-found/not-found.component';
import { ViewCategoryComponent } from './Components/Category/view-category/view-category.component';
import { AddOrEditCategoryComponent } from './Components/Category/add-or-edit-category/add-or-edit-category.component';


const routes: Routes = [
  { path: "", component: HomeComponent },
  {
    path: "customers", children: [
      { path: "", component: ViewCustomersComponent },
      { path: "addcustomer", component: AddOrEditCustomerComponent },
      { path: "editcustomer/:id", component: AddOrEditCustomerComponent }
    ]
  },
  {
    path: "categories", children: [
      { path: "", component: ViewCategoryComponent },
      { path: "addcategory", component: AddOrEditCategoryComponent },
      { path: "editcategory/:id", component: AddOrEditCategoryComponent }
    ]
  },
  { path: "editcustomer", component: AddOrEditCustomerComponent },
  { path: "**", component: NotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
