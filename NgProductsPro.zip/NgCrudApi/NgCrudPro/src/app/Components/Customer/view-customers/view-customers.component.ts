import { Component, OnInit } from '@angular/core';
import { CustomerSrvService } from 'src/app/Services/customer-srv.service';

@Component({
  selector: 'app-view-customers',
  templateUrl: './view-customers.component.html',
  styleUrls: ['./view-customers.component.css']
})
export class ViewCustomersComponent implements OnInit {
  customers;
  constructor(public service: CustomerSrvService) { }

  ngOnInit(): void {
    this.loadCustomer();
  }
  loadCustomer() {
    this.service.getAll().subscribe(s => {
      console.log(s);
      this.customers = s;
    })
  }
}
