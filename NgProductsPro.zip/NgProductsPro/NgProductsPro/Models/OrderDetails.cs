﻿using System.ComponentModel.DataAnnotations.Schema;

namespace NgProductsPro.Models
{
    public class OrderDetails
    {
        public int Id { get; set; }
        [ForeignKey("Order")]
        public int OrderID { get; set; }
        [ForeignKey("Product")]
        public int PrdID { get; set; }
        public int Qty { get; set; }

        public Order Order { get; set; }
        public Product Product { get; set; }
    }
}
